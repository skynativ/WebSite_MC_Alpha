<?php
class ApiConfiguration extends AppModel {
}